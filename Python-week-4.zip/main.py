def large_power(base, exponent):
  result = base ** exponent
  return result > 5000
print(large_power(10, 3))  
print(large_power(2, 10)) 

def divisible_by_ten(num):
  return num % 10 == 0
print(divisible_by_ten(20)) 
print(divisible_by_ten(25))
def calculate_discount(price, discount_percent):
  if discount_percent >= 20:
      return price * (1 - discount_percent / 100)
  else:
      return price
print(calculate_discount(100, 25))  
print(calculate_discount(50, 15))  
def calculate_discount(price, discount_percent):
  if discount_percent >= 20:
      return price * (1 - discount_percent / 100)
  else:
      return price
original_price = 60
discount_percentage = 20
final_price = calculate_discount(original_price, discount_percentage)

if final_price == original_price:
  print("No discount applied. The final price is:", original_price)
else:
  print("The final price after applying the discount is:", final_price)